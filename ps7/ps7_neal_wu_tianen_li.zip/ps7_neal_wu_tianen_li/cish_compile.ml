exception FAILBLOG

let result2string a = raise FAILBLOG
let compile a = raise FAILBLOG
