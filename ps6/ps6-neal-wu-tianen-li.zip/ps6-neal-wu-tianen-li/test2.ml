(fun x -> x + 42*7) 3
