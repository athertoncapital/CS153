let id = fun x -> x in
let pair = (id,id) in
let p2 = ((fst pair) nil, (snd pair) false) in
fst p2
