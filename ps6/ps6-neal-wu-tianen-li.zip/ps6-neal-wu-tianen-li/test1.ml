let x = 42 * 7 + 3 in
let y = 4 + 42 * 7 in
x + y
